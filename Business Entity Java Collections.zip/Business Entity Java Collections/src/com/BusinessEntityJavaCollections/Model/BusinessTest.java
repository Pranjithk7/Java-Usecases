package com.BusinessEntityJavaCollections.Model;

public class BusinessTest {
private Long BusinessIdentifier;
private String BusinessName;
private RegisteredAddress Address;
private MailingAddress mailingaddress;
private int FailureScore;
private String CountryCode;
public BusinessTest(Long businessIdentifier, String businessName, RegisteredAddress address,
		MailingAddress mailingaddress, int failureScore, String countryCode) {
	this.BusinessIdentifier = businessIdentifier;
	this.BusinessName = businessName;
	this.Address = address;
	this.mailingaddress = mailingaddress;
	this.FailureScore = failureScore;
	this.CountryCode = countryCode;
}
public Long getBusinessIdentifier() {
	return BusinessIdentifier;
}
public void setBusinessIdentifier(Long businessIdentifier) {
	BusinessIdentifier = businessIdentifier;
}
public String getBusinessName() {
	return BusinessName;
}
public void setBusinessName(String businessName) {
	BusinessName = businessName;
}
public RegisteredAddress getAddress() {
	return Address;
}
public void setAddress(RegisteredAddress address) {
	Address = address;
}
public MailingAddress getMailingaddress() {
	return mailingaddress;
}
public void setMailingaddress(MailingAddress mailingaddress) {
	this.mailingaddress = mailingaddress;
}
public int getFailureScore() {
	return FailureScore;
}
public void setFailureScore(int failureScore) {
	FailureScore = failureScore;
}
public String getCountryCode() {
	return CountryCode;
}
public void setCountryCode(String countryCode) {
	CountryCode = countryCode;
}
}
