import javax.xml.parsers.DocumentBuilderFactory;  
import javax.xml.parsers.DocumentBuilder;  
import org.w3c.dom.Document;  
import org.w3c.dom.NodeList;  
import org.w3c.dom.Node;  
import org.w3c.dom.Element;  
import java.io.File;  
public class JavaXMLParsing 
{  
public static void main(String args[])   
{  
try   
{  
String filePath="XMLFile.xml";
File file = new File(filePath);  
//Instance of factory that gives a document builder
DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
//Instance of builder to parse the specified xml file
DocumentBuilder db = dbf.newDocumentBuilder();  
Document doc = db.parse(file);  
doc.getDocumentElement().normalize();    
NodeList nodeList = doc.getElementsByTagName("SampleProductResponse");  
for (int itr = 0; itr < nodeList.getLength(); itr++)   
{  
Node node = nodeList.item(itr);    
if (node.getNodeType() == Node.ELEMENT_NODE)   
{  
Element eElement = (Element) node;  
System.out.println("Business Identification Number:"+ eElement.getElementsByTagName("BusinessNumber").item(0).getTextContent());  
System.out.println("Business Name:"+ eElement.getElementsByTagName("BusinessName").item(0).getTextContent());  
System.out.println("Registered Address:"+ eElement.getElementsByTagName("AddressLines").item(0).getTextContent());   
}  
}  
}   
catch (Exception e)   
{  
e.printStackTrace();  
}  
}  
}  
