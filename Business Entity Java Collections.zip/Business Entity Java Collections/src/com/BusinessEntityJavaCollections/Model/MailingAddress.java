package com.BusinessEntityJavaCollections.Model;

public class MailingAddress {

	private String MailingAddressLine;
    private String MailPostalCode;
    private String MailingTown;
    private String MailingCountry;

       public MailingAddress() {
    }

 

    public MailingAddress(String addressLine, String postalCode, String town, String country) {
        this.MailingAddressLine = addressLine;
        this.MailPostalCode = postalCode;
        this.MailingTown = town;
        this.MailingCountry = country;
    }

 

    @Override
    public String toString() {
        return MailingAddressLine + ", \n \t \t \t" + MailPostalCode + "," + MailingTown + ", \n \t \t \t"
                + MailingCountry;
    }

 

    public String getAddressLine() {
        return MailingAddressLine;
    }

 

    public void setAddressLine(String addressLine) {
        this.MailingAddressLine = addressLine;
    }

 

    public String getPostalCode() {
        return MailPostalCode;
    }

 

    public void setPostalCode(String postalCode) {
        this.MailPostalCode = postalCode;
    }

 

    public String getTown() {
        return MailingTown;
    }

 

    public void setTown(String town) {
        this.MailingTown = town;
    }

 

    public String getCountry() {
        return MailingCountry;
    }

 

    public void setCountry(String country) {
        this.MailingCountry = country;
    }


}
 