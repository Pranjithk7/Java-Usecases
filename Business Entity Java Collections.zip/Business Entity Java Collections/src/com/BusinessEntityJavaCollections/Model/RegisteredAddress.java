package com.BusinessEntityJavaCollections.Model;

public class RegisteredAddress {

	private String senderAddressLine;
	private String PostalCode;
	private String Town;
	private String Country;
	public RegisteredAddress() {
	}
	public RegisteredAddress(String addressLine, String postalCode, String town, String country) {
		this.senderAddressLine = addressLine;
		this.PostalCode = postalCode;
		this.Town = town;
		this.Country = country;
	}
	@Override
	public String toString() {
		return senderAddressLine + ",\n\t\t"+ PostalCode+","+Town+",\n\t\t"+Country;
	}
	public String getAddressline() {
		return senderAddressLine;
	}
	public void setAddressline(String addressline) {
		this.senderAddressLine = addressline;
	}
	public String getPostalCode() {
		return PostalCode;
	}
	public void setPostalCode(String postalCode) {
		PostalCode = postalCode;
	}
	public String getTown() {
		return Town;
	}
	public void setTown(String town) {
		Town = town;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
}