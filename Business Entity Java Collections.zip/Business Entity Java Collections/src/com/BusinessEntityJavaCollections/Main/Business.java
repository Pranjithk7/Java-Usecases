package com.BusinessEntityJavaCollections.Main;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.BusinessEntityJavaCollections.Model.BusinessTest;
import com.BusinessEntityJavaCollections.Model.MailingAddress;
import com.BusinessEntityJavaCollections.Model.RegisteredAddress;

public class Business {
	public static void main(String args[]){
		ArrayList<BusinessTest> dataList=new ArrayList<BusinessTest>();
		RegisteredAddress address=new RegisteredAddress("12 Queens Park","GB1024","Birmingham","United Kingdom");
		MailingAddress mail=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA" , "Hertfordshire", "United Kingdom");
		BusinessTest data=new BusinessTest((long) 999999990,"Tesco", address,mail,90,"GB");
		dataList.add(data);
		RegisteredAddress address1=new RegisteredAddress("Churchil Palace", "E14 5HP", "London", "United Kingdom");
		MailingAddress mail1=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA", "Hertfordshire", "United Kingdom");
		BusinessTest data1=new BusinessTest((long)999999991,"Barclays", address1,mail1,85,"GB");
		dataList.add(data1);
		RegisteredAddress address2=new RegisteredAddress("65 Lake Street", "06100", "Paris","France");
		MailingAddress mail2=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA", "Hertfordshire", "United Kingdom");
		BusinessTest data2=new BusinessTest((long)888888880,"Soc Generale", address2,mail2,55,"FR");
		dataList.add(data2);
		RegisteredAddress address3=new RegisteredAddress("65 Lake Street", "06100", "Paris","France");
		MailingAddress mail3=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA", "Hertfordshire", "United Kingdom");
		BusinessTest data3=new BusinessTest((long)888888881,"Cisco", address3,mail3,97, "GB");
		dataList.add(data3);
		RegisteredAddress address4=new RegisteredAddress("65 Lake Street", "06100", "Paris","France");
		MailingAddress mail4=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA", "Hertfordshire", "United Kingdom");
		BusinessTest data4=new BusinessTest((long)888888882,"PoundLand", address4,mail4,99,"GB");
		dataList.add(data4);
		RegisteredAddress address5=new RegisteredAddress("65 Lake Street", "06100", "Paris","France");
		MailingAddress mail5=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA", "Hertfordshire", "United Kingdom");
		BusinessTest data5=new BusinessTest((long)888888883,"Amazon", address5,mail5,65, "GB");
		dataList.add(data5);
		RegisteredAddress address6=new RegisteredAddress("65 Lake Street", "06100", "Paris","France");
		MailingAddress mail6=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA", "Hertfordshire", "United Kingdom");
		BusinessTest data6=new BusinessTest((long)888888884,"Flipkart", address6,mail6,77, "GB");
		dataList.add(data6);
		RegisteredAddress address7=new RegisteredAddress("65 Lake Street", "06100", "Paris","France");
		MailingAddress mail7=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA", "Hertfordshire", "United Kingdom");
		BusinessTest data7=new BusinessTest((long)888888885,"Ajio", address7,mail7,83, "GB");
		dataList.add(data7);
		RegisteredAddress address8=new RegisteredAddress("65 Lake Street", "06100", "Paris","France");
		MailingAddress mail8=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA", "Hertfordshire", "United Kingdom");
		BusinessTest data8=new BusinessTest((long)888888886,"Myntra", address8,mail8,89, "GB");
		dataList.add(data8);
		RegisteredAddress address9=new RegisteredAddress("65 Lake Street", "06100", "Paris","France");
		MailingAddress mail9=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA", "Hertfordshire", "United Kingdom");
		BusinessTest data9=new BusinessTest((long)888888887,"Philips", address9,mail9,45, "GB");
		dataList.add(data9);
		
		Collections.sort(dataList,Comparator.comparingInt(BusinessTest::getFailureScore).reversed());
		for(BusinessTest businesstest:dataList){
			System.out.println("Business Identifier\t:"+businesstest.getBusinessIdentifier());
			System.out.println("Business Name\t:"+businesstest.getBusinessName());
			System.out.println("Registered Address\t:"+businesstest.getAddress());
			System.out.println("Mailing Address\t:"+businesstest.getMailingaddress());
			System.out.println("Failure Score\t:"+businesstest.getFailureScore());
			System.out.println("--------------Descending Order----------");
			
		}
	}

}
